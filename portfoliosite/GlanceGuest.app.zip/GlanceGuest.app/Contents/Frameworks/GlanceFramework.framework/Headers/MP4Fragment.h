//
//  MP4Fragment.h
//  DeviceVideo
//
//  Created by Ilya Belenkiy on 10/25/17.
//  Copyright © 2017 Glance. All rights reserved.
//

#ifndef MP4Fragment_h
#define MP4Fragment_h

#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import "Ap4Types.h"

typedef void (^MP4FragmentCompletion)(NSData* _Nonnull moov_dat, NSData* _Nonnull moof_dat);

@interface MP4Fragment: NSObject {
@private
    AP4_UI32 moofs_sequence_number;
    AP4_UI64 moofs_duration;
}

- (void)reset;
- (void)encodeWithData:(NSData* _Nonnull)data frameRate:(CMTimeScale)frameRate completion:(MP4FragmentCompletion _Nonnull)completion;

@end

#endif /* MP4Fragment_h */
