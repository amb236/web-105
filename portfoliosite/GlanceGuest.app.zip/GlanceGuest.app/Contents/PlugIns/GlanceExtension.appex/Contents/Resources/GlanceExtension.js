var GLANCE = GLANCE || {};
GLANCE._Client = GLANCE._Client || {};
GLANCE._Client.Safari = GLANCE._Client.Safari || {};

(function () {
 // ------------ start scope
 
 var Callbacks = {};
 
 function sendGlanceScriptMessage(message, arg, cf)
 {
    var cb = "cb" + Math.floor(Math.random(100000000) * 100000000);
 
    Callbacks[cb] = cf;
    window.postMessage({from: "GlanceExtension", message: message, arg: arg, callback: cb}, "*");
 }
 
function handleGlanceScriptResponse(event)
{
    var data = event.data;
    var cb = Callbacks[data.callback];
 
    if (!cb) {
        console.log("GlanceExtenson: unknown callback '" + data.callback + "'");
        return;
    }
 
    cb(data.value);
    delete Callbacks[data.callback];
}
 
window.addEventListener("message", function(event) {
    // We only accept messages from this window
    if (event.source != window)
        return;
    // check event.origin
    if (event.data.from == "GlanceScript")
        handleGlanceScriptResponse(event);
}, false);

// Public API
 
// Returns client version:
//    {version: versionstring, bundleVersion: bundleversionstring isguest:bool extensioninstalled: bool, usesextension: bool, versiondetection: boolean }
// Example:
//    {"version":"4.2.0","bundleVersion":"402.0.36","versiondetection":true,"usesextension":true,"isguest":true,"extensioninstalled":true}
// Example calls:
//    GLANCE.Client.Safari.GetGlanceClientVersion(function (v) { alert('version is ' + v.version); })
//    GLANCE.Client.Safari.GetGlanceClientVersion(function (v) { alert('GetGlanceClientVersion returned ' + JSON.stringify(v)); })
GLANCE._Client.Safari.GetGlanceClientVersion = function (cf) {
    sendGlanceScriptMessage("GetGlanceClientVersion", {}, cf);
}

 // Invoke the Glance client application with a command
 //   command is {invokeClient: url}
 // Example:
 //   GLANCE.Client.Safari.InvokeClient({invokeClient: "glance://startssn?groupid=13010&visitor=1"}, function (r) { alert('invoke returned ' + JSON.stringify(r)); })
 //   GLANCE.Client.Safari.InvokeClient({invokeClient: "glance://endssn"}, function (r) { alert(r.code != 0 ? "Session ended" : "Error: " + r.message); })
 GLANCE._Client.Safari.InvokeClient = function (command, cf) {
    sendGlanceScriptMessage("InvokeClient", command, cf);
 }
 
GLANCE._Client.Safari.test1 = function (cf) {
    sendGlanceScriptMessage("test1", {}, cf);
}
 
GLANCE._Client.Safari.test2 = function (cf) {
    sendGlanceScriptMessage("test2", {}, cf);
}
 
// ------------ end scope
})();


