document.addEventListener("DOMContentLoaded", function(event) {
    safari.extension.dispatchMessage("Glance script loaded, loading GlanceExtension script");
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = safari.extension.baseURI + "GlanceExtension.js";
    document.head.appendChild(s);
});

var Callbacks = {};
    
function sendNativeMessage(message, arg, cf)
{
    var cb = "cb" + Math.floor(Math.random(100000000) * 100000000);

    Callbacks[cb] = cf;
    safari.extension.dispatchMessage(message, {"arg": arg, "callback": cb});
}

function handleNativeCallback(event)
{
    var cb = Callbacks[event.name];
    
    if (!cb) {
        console.log("GlanceScript: unknown callback '" + event.name + "'");
        return;
    }
    
    cb(event.message);
    delete Callbacks[event.name];
}

safari.self.addEventListener("message", handleNativeCallback);

function handleGlanceExtensionMessage(event)
{
    var data = event.data;
    
    function respond(v)
    {
        window.postMessage({from: "GlanceScript", callback: data.callback, value: v},
                           event.origin);
    }
    
    switch (data.message) {
        case "GetGlanceClientVersion":
            sendNativeMessage("GetGlanceClientVersion", {}, function (value) { respond(value); });
            return;
            
        case "InvokeClient":
            sendNativeMessage("InvokeClient", data.arg, function (value) { respond(value); });
            return;
            
        case "test2":
            sendNativeMessage("test2", {}, function (value) { respond(value); });
            return;
            
        case "test1":
            respond({test: "test1"});
            return;
            
        default:
            console.log("Unknown GlanceExtension message '" + data.message + "'");
    }
}

window.addEventListener("message", function(event) {
    // We only accept messages from ourselves
    if (event.source != window)
        return;
    // should check event.origin for one of our allowed domains?
    if (event.data.from == "GlanceExtension")
         handleGlanceExtensionMessage(event);
}, false);
